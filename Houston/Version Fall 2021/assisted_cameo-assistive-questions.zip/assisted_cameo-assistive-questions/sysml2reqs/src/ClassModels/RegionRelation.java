package ClassModels;

public class RegionRelation {
		
		private String relationSource;
		private String relationTarget;
		
		public String getRelationSource() {
			return relationSource;
		}
		public void setRelationSource(String relationSource) {
			this.relationSource = relationSource;
		}		
		public String getRelationTarget() {
			return relationTarget;
		}
		public void setRelationTarget(String relationTarget) {
			this.relationTarget = relationTarget;
		}

}
