package ClassModels;

public class PCflow {
	
	private String flowName;
	private String convoyedName;
	private String sourceName;
	private String targetName;
	
	public String getFlowName() {
		return flowName;
	}
	public void setFlowName(String flowName) {
		this.flowName = flowName;
	}
	public String getConvoyedName() {
		return convoyedName;
	}
	public void setConvoyedName(String convoyedName) {
		this.convoyedName = convoyedName;
	}
	public String getSourceName() {
		return sourceName;
	}
	public void setSourceName(String sourceName) {
		this.sourceName = sourceName;
	}
	public String getTargetName() {
		return targetName;
	}
	public void setTargetName(String targetName) {
		this.targetName = targetName;
	}
	

}
