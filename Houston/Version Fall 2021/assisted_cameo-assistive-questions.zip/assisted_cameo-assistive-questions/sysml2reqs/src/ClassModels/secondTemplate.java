package ClassModels;

public class secondTemplate {
	
	private String object;
	private String accOrProvide;
	private String diagramElement;
	private String action1;
	private String action2;
	private String condition;
	
	public String getObject() {
		return object;
	}
	public void setObject(String object) {
		this.object = object;
	}
	public String getAccOrProvide() {
		return accOrProvide;
	}
	public void setAccOrProvide(String accOrProvide) {
		this.accOrProvide = accOrProvide;
	}
	public String getDiagramElement() {
		return diagramElement;
	}
	public void setDiagramElement(String diagramElement) {
		this.diagramElement = diagramElement;
	}
	public String getAction1() {
		return action1;
	}
	public void setAction1(String action1) {
		this.action1 = action1;
	}
	public String getAction2() {
		return action2;
	}
	public void setAction2(String action2) {
		this.action2 = action2;
	}
	public String getCondition() {
		return condition;
	}
	public void setCondition(String condition) {
		this.condition = condition;
	}
	
}
