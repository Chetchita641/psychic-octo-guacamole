package ClassModels;

public class thirdTemplate {

	private String object;
	private String timeDependency;
	private String durationConstraint;
	private String action1;
	private String action2;
	
	public String getObject() {
		return object;
	}
	public void setObject(String object) {
		this.object = object;
	}
	public String getTimeDependency() {
		return timeDependency;
	}
	public void setTimeDependency(String timeDependency) {
		this.timeDependency = timeDependency;
	}
	public String getDurationConstraint() {
		return durationConstraint;
	}
	public void setDurationConstraint(String durationConstraint) {
		this.durationConstraint = durationConstraint;
	}
	public String getAction1() {
		return action1;
	}
	public void setAction1(String action1) {
		this.action1 = action1;
	}
	public String getAction2() {
		return action2;
	}
	public void setAction2(String action2) {
		this.action2 = action2;
	}
	
}
