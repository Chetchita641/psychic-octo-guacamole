package ClassModels;

public class stringList {

}
