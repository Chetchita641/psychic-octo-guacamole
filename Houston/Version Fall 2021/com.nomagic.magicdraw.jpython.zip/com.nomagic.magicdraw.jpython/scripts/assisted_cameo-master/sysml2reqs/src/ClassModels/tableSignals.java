package ClassModels;

import java.util.List;

public class tableSignals {
	
	private String tableName;
	private List<String> tableRequirements;
}
