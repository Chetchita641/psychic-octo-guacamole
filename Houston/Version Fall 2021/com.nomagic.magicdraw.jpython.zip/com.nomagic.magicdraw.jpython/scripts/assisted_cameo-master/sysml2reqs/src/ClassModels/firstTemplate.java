package ClassModels;

public class firstTemplate {
	
	private String object;
	private String accOrProvide;
	private String inOrOut;
	private String portInterface;
	private String source1;
	private String source2;
	
	public String getObject() {
		return object;
	}
	public void setObject(String object) {
		this.object = object;
	}
	public String getAccOrProvide() {
		return accOrProvide;
	}
	public void setAccOrProvide(String accOrProvide) {
		this.accOrProvide = accOrProvide;
	}
	public String getInOrOut() {
		return inOrOut;
	}
	public void setInOrOut(String inOrOut) {
		this.inOrOut = inOrOut;
	}
	public String getPortInterface() {
		return portInterface;
	}
	public void setPortInterface(String portInterface) {
		this.portInterface = portInterface;
	}
	public String getSource1() {
		return source1;
	}
	public void setSource1(String source1) {
		this.source1 = source1;
	}
	public String getSource2() {
		return source2;
	}
	public void setSource2(String source2) {
		this.source2 = source2;
	}
	
	
	
	

}
